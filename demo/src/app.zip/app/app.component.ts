import { Component,OnInit } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { EventService } from "./event.service";


@Component({
 selector: 'app-root',
 templateUrl: './app.component.html',
 styleUrls: [ './app.component.css' ]
})
export class AppComponent {
 public userForm: FormGroup;
 constructor(private _fb: FormBuilder,
 private eventservice:EventService) { }

 ngOnInit() {
 this.userForm = this._fb.group({
 name: [''],
 email:[''],
 agenda: this._fb.array([
 this.initAddress(),
 ])
 });
 }

 initAddress() {
 return this._fb.group({
 street: [''],
 city:[''],
 postalcode: ['']
 });
 }

 addAddress() {
 const control = <FormArray>this.userForm.controls['agenda'];
 control.push(this.initAddress());
 }

 removeAddress(i: number) {
 const control = <FormArray>this.userForm.controls['agenda'];
 control.removeAt(i);
}
 onSubmit()
 {
      alert(this.userForm.value);
      let json=JSON.stringify(this.userForm.value);
      //JSON.stringify(json);
      this.eventservice.addEvent(json);
      alert(json);
      this.eventservice.getEvents();
 }


//  save(model: Customer) {
//  // call API to save
//  // ...
//  console.log(model);
//  }
}
