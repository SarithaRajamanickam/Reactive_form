import { Component,OnInit } from '@angular/core';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { EventService } from "./event.service";
import { Event } from './event';
import { Agenda } from "./agenda";


@Component({
 selector: 'app-root',
 templateUrl: './app.component.html',
 styleUrls: [ './app.component.css' ]
})

export class AppComponent {
 public userForm: FormGroup;
 statusCode: number;
 events:Event[];
 eId:null;


 constructor(private _fb: FormBuilder,
 private eventservice:EventService) { }

 ngOnInit() {
this.getEvents();
 this.userForm = this._fb.group({
 agenda: this._fb.array([
 this.initAddress(),
 ]),
 eId:[''],
 email:[''],
 name: ['']
});
 
 }

 initAddress() {
 return this._fb.group({
  city:[''],
  id:[''],
  postalcode: [''],
 street: ['']
 });
 }

 addAddress() {
 const control = <FormArray>this.userForm.controls['agenda'];
 control.push(this.initAddress());
 }

 removeAddress(i: number) {
 const control = <FormArray>this.userForm.controls['agenda'];
 control.removeAt(i);
}
getEvents() {
    alert("getevents");
       this.eventservice.getEvents()
	   .subscribe(
                data => this.events = data,
                errorCode =>  this.statusCode = errorCode);   
   }
 onSubmit()
 {
    alert("submit");
     this.eventservice.addEvent(this.userForm.value)
            .subscribe(successCode => {
                this.statusCode = successCode;
            },
            errorCode => this.statusCode = errorCode);
            
             this.getEvents();
             this.toClear(); 
              
             
    }
     
forDelete(eId:number)
{
    
      this.eventservice.deleteEvent(eId)
	      .subscribe(successCode => {
		      this.getEvents();	
		     
		   },
		   errorCode => this.statusCode = errorCode);    
   }
toClear() {
    alert("clear");
          this.eId = null;
          this.userForm.reset();
   }
 toEdit(eId: number) {
     
      this.eventservice.getEvent(eId)
	      .subscribe(event => {
		            this.eId = event.eId;   
		            this.userForm.setValue({ eId:event.eId, name: event.name,email:event.email,agenda:event.agenda }); 
		    },
		    errorCode =>  this.statusCode = errorCode);   
   }
   
   toUpdate()
   {
      this.eventservice.updateEvent(this.eId,this.userForm.value)
      .subscribe(todos => {
        this.userForm = todos;
        this.getEvents();
        this.toClear();
      });
    }
}
 


 
