export class Agenda {
    constructor(public  id:number,public street: string,public city:string, public postalcode: string){}
}
